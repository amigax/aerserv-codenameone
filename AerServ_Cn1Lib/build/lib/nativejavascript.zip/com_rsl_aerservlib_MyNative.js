(function(exports){

var o = {};

    o.setProduction_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.onCreate_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setDev_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.showInterstitial_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.onPause_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.loadInterstitial_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getPlc_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.pauseBanner_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.showBanner_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.onDestroy_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.onResume_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.playBanner_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setStaging_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.preloadInterstitial_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_rsl_aerservlib_MyNative= o;

})(cn1_get_native_interfaces());
