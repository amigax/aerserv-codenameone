#import "com_rsl_aerservlib_MyNativeImpl.h"

@implementation com_rsl_aerservlib_MyNativeImpl

-(void)setProduction{
}

-(void)onCreate{
}

-(void)setDev{
}

-(void)showInterstitial{
}

-(void)onPause{
}

-(void)loadInterstitial{
}

-(NSString*)getPlc{
    return nil;
}

-(void)pauseBanner{
}

-(void)showBanner{
}

-(void)onDestroy{
}

-(void)onResume{
}

-(void)playBanner{
}

-(void)setStaging{
}

-(void)preloadInterstitial{
}

-(BOOL)isSupported{
    return NO;
}

@end
