namespace com.rsl.aerservlib{

using System;
using System.Windows;

public class MyNativeImpl {
    public void setProduction() {
    }

    public void onCreate() {
    }

    public void setDev() {
    }

    public void showInterstitial() {
    }

    public void onPause() {
    }

    public void loadInterstitial() {
    }

    public String  getPlc() {
        return null;
    }

    public void pauseBanner() {
    }

    public void showBanner() {
    }

    public void onDestroy() {
    }

    public void onResume() {
    }

    public void playBanner() {
    }

    public void setStaging() {
    }

    public void preloadInterstitial() {
    }

    public bool isSupported() {
        return false;
    }

}
}
